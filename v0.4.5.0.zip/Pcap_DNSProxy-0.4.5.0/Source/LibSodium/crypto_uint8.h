#ifndef crypto_uint8_H
#define crypto_uint8_H

#include <stdint.h>

typedef uint8_t crypto_uint8;

#endif
