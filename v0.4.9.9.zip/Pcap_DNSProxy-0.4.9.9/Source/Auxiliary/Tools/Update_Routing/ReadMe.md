﻿## Usage

* Run `Updata.bat` in cmd.

## Commands

* `-LOCAL`
  Build from cache file.

## Files

* `#Routingipv4#`
  IPv4 database cache.
* `#Routingipv6#`
  IPv6 database cache.
* `delegated-apnic-latest`
  Original APNIC database.
* `Log_Lib`
  IPv4 netmask to IPv4 prefix length conversion library.
* `latest` folder
  Cache folder.
* `Routing.txt`
  The output file.
